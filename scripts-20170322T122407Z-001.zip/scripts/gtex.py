#!/usr/bin/env python2


import collections
samples = collections.defaultdict(list)
with open('/Users/carol/Desktop/Gtex-brain.txt') as f:
  brainsamples = [l.strip() for l in f if l.strip()]            


#print (brainsamples)



### funcionando e eu consegui as linhas do arquivo cerebro


d = open('/Users/Carol/Desktop/GTEx_Analysis_v6_RNA-seq_RNA-SeQCv1.1.8_gene_reads.gct') 

for row in d:
  if row[0] in brainsamples:
   print (d)

  else:

   print('no') 
bb