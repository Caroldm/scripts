#!/usr/bin/env python2

import csv

with open("/Users/carol/Desktop/Gtex-brain.csv") as f open('/Users/Carol/Desktop/GTEx_Analysis_v6_RNA-seq_RNA-SeQCv1.1.8_gene_reads.gct') as f2:
    st  = set(map(str.rstrip, f)) # itertools.imap python2
    for line in f2:
        # split once and extract first element to compare
        if line.strip() and line.split(None, 1)[0] in st:
            print(line.rstrip()) 