#!/usr/bin/env python2

import csv

 genes = []
    a_vals = []
    b_vals = []

with open('/Users/Carol/Desktop/GTEx_Analysis_v6_RNA-seq_RNA-SeQCv1.1.8_gene_reads.txt', 'rU') as csvfile:
        reader = csv.reader(csvfile, delimiter='\t')
        # First line should be column names.
        names = next(csvfile)
        names = names.strip().split('\t')
        samples = next(csvfile)
        samples = samples.strip().split('\t')

        # Convert to a string so we can use rindex next.
        indices = ''.join(samples)
        # +1 to account for the leftmost gene symbol column.
        idx = indices.index('1')+1

        for line in reader:
            genes.append(line[0])
            a_row = line[1:idx]
            b_row = line[idx:]
            a_vals.append([float(pv) for pv in a_row])
            b_vals.append([float(pv) for pv in b_row])
    return (genes, a_vals, b_vals, zip(names, samples))





count = 0
import csv
import collections
with open('/Users/carol/Desktop/Gtex-brain.txt') as d:
  sites = set(l.strip() for l in d)
  
  #  sites = [l.strip() for l in d if l.strip()]      
  #print(sites)
###Now you can do efficient membership tests per line, provided you can split your lines:

with open('/Users/Carol/Desktop/GTEx_Analysis_v6_RNA-seq_RNA-SeQCv1.1.8_gene_reads.txt','r') as inF:
   for line in inF:
       elements = line.split()
       if sites.intersection(elements):
          count += 1


# Find column indices.
            a_indices = [header.index(gtex) for gtex in a_cols]
            b_indices = [header.index(gtex) for gtex in b_cols]
            selections['a_indices'] = a_indices
            selections['b_indices'] = b_indices

            for line in soft_in:
                split_line = line.rstrip('\r\n').split('\t')
                if split_line[0] == EOF or split_line[1] == '--Brain':
                    continue

                probe  = split_line[0]
                values = split_line[COL_OFFSET:]

                

                a_row = [float(values[i]) for i in a_indices]
                b_row = [float(values[i]) for i in b_indices]
                a_vals.append(a_row)
                b_vals.append(b_row)
                genes.append(gene)

                return (genes, a_vals, b_vals, selections)


conda install anaconda-client