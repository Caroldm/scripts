import os, sys
import numpy as np
import pandas as pd
from scipy.stats import zscore, mstats
from pprint import pprint
import matplotlib.pyplot as plt

HOME = os.path.expanduser('~')
sys.path.append(HOME + '/Documents/bitbucket/maayanlab_utils')
from RNAseq import PCA_plot, PCA_3d_plot
from normalizations import quantile_norm


## load data from txt files
def load_data(fn):
	df = pd.read_csv(fn, sep='\t', skiprows=3)
	df.set_index(df.columns[0], inplace=True)
	with open (fn, 'r') as f:
		for line in f:
			if line.startswith('Accession'):
				accessions = line.strip().split('\t')[1:]
	return df, accessions


df570, accessions570 = load_data('GPL570.txt')
#df6244, accessions6244 = load_data('GPL6244_1.txt')

print df570.head()
print df570.shape#, df6244.shape
print len(accessions570), len(accessions6244)


# mat = df570.values
# samples = [ '%s_%s' %(gds, gsm) for gsm, gds in zip(df570.columns, accessions570)]

# mat = df6244.values
# samples = [ '%s_%s' %(gds, gsm) for gsm, gds in zip(df6244.columns, accessions6244)]


#df_merged = df570.merge(df6244, left_index=True, right_index=True)
#print df_merged.shape
#mat = df_merged.values
# samples = [ '%s_%s' %(gds, gsm) for gsm, gds in zip(df_merged.columns, accessions570 + accessions6244)]
#for i, gsm in enumerate(accessions570):
#	samples.append('GPL570_%s' %i)
#for i, gsm in enumerate(accessions6244):
#	samples.append('GPL6244_%s' %i)

PCA_plot(quantile_norm(mat), samples, standardize=2, log=True, show_text=False, sep='_', legend_loc='upper left', legend_size=10)
PCA_3d_plot(quantile_norm(mat), samples, standardize=2, log=True, show_text=False, sep='_', legend_loc='lower right')
