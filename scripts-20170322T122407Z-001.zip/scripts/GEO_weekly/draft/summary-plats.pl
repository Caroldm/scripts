#!/usr/local/bin/perl

use strict;
use autodie;
use warnings;
use Data::Dump;

use LWP::Simple qw(get);

my $content=get ('http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=gds&query_key=1&WebEnv=NCID_1_64462223_130.14.18.34_9001_1447189964_121015723_0MetA0_S_MegaStore_F_1&usehistory=y');

dd$ content;
