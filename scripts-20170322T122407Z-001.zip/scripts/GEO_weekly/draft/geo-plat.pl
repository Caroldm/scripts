#!/usr/local/bin/perl
use strict;
use warnings;
use autodie;
use Data::Dump;

use LWP::Simple qw(get);

my $content=get('http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=gds&term=GPL8321[ACCN]+AND+mammals[ORGN]+AND+"published+last+3+months"[Filter]&usehistory=y');

dd $content;




