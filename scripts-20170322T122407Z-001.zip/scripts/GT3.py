#!/usr/bin/env python2

import csv

count = 0

import collections
samples = collections.defaultdict(list)
with open('/Users/carol/Desktop/Gtex-brain.txt') as f:
 sites = [l.strip() for l in f if l.strip()]      

###Now you can do efficient membership tests per line, provided you can split your lines:

with open('/Users/Carol/Desktop/GTEx_Analysis_v6_RNA-seq_RNA-SeQCv1.1.8_gene_reads.gct','r') as inF:
   for line in inF:
       elements = line.split()
       if sites.intersection(elements):
          count += 1

          print (elements)

