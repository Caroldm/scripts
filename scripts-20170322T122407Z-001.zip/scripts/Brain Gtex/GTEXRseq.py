# read and parse A content
file_a = '/Users/carol/Desktop/brain20vs50.txt'
with open(file_a) as filea:
    a_data = [a.strip() for a in filea]

# read and parse B content
file_b = '/Users/Carol/Desktop/GTEx_Analysis_v6_RNA-seq_RNA-SeQCv1.1.8_gene_reads.txt'
with open(file_b) as fileb:
    b_data = [[l.strip() for l in line.split()] for line in fileb]

# get target columns indexes
# include 'field' and 'id' index
# while loop nested in for loop to ignore the ValueError
indexes = [0, 1]
for a in a_data:
     indexes.append(b_data[0].index(a))

print(indexes.append(b_data[0].index(a)))
# filter data
new_data = []
for line in b_data:
    new_line = []

    for index in indexes:
        new_line.append(line[index])

    new_data.append(new_line)

# separate columns by tabs and rows by line breaks
new_data_string = '\n'.join(['\t'.join(line) for line in new_data])

# save merged data
print(new_data_string)
new_file = '/Users/Carol/Desktop/gtex_analysis/20-50brain-out.txt'
f = open(new_file, 'w')
f.write(new_data_string)
f.close()