#!/usr/bin/env python2


import collections
samples = collections.defaultdict(list)
with open('/Users/carol/Desktop/GTEX/Gtex-brain.gct') as f:
  brainsamples = [l.strip() for l in f if l.strip()]            


print (brainsamples)



### funcionando e eu consegui as linhas do arquivo cerebro


#d = ('/Users/carol/Desktop/GTEX/Gtex-brain.gct') 

#for name in d:
 #   if name in brainsamples
  #    print(d)
  