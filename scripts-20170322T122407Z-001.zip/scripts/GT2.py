#!/usr/bin/env python2

#import csv

count = 0

#with open ('/Users/carol/Desktop/Gtex-brain.txt','r') as d:
   #  sites = set(l.strip() for l in d)
###Now you can do efficient membership tests per line, provided you can split your lines:

#with open('/Users/Carol/Desktop/GTEx_Analysis_v6_RNA-seq_RNA-SeQCv1.1.8_gene_reads.gct','r') as inF:
 #  for line in inF:
  #     elements = line.split()
   #    if sites.intersection(elements):
    #      print(line)

         
 #import sys
 #import csv
 #import collections

 #samples = collections.defaultdict(list)
 #with open('/Users/carol/Desktop/Gtex-brain.txt','r') as f:
   #brainsamples = [l.strip() for l in f if l.strip()] 

 #print (brainsamples)

 #with open ('/Users/Carol/Desktop/GTEx_Analysis_v6_RNA-seq_RNA-SeQCv1.1.8_gene_reads.gct','r') as inF:
   #for row in inF:
     #elements = row.split()
     #if brainsamples.intersection(elements):
       # print(row[0,:])

import csv

with open ('/Users/carol/Desktop/Gtex-brain.xlsx','r') as d:
    sites = set(l.strip() for l in d)
###Now you can do efficient membership tests per line, provided you can split your lines:
    #print (sites)

with open ('/Users/Carol/Desktop/GTEx_Analysis_v6_RNA-seq_RNA-SeQCv1.1.8_gene_reads.gct','r') as inF:
   for line in inF:
    elements = line.split()
    print(elements)

  