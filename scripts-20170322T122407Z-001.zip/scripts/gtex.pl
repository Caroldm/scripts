#!/usr/bin/env python2

import csv

with open ('/Users/carol/Desktop/GTEX/Gtex-brain.txt') as brainlist;
data = csv.reader(brainlist)

with open ('/Users/carol/Desktop/GTEX/Gtex-brain.gct') as braindata;
data2 = csv.reader(braindata)
        for row in data2:
          if row[0] in data2 = row[0] in data;
           print (data2)


# write to file
    with open('/Users/carol/Desktop/Gtexbrainfull.txt', 'w+') as output:

            output.write(data2+ '\n')


    





