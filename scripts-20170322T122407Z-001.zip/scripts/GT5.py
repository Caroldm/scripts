#!/usr/bin/env python2

import csv
from itertools import izip
a = izip(*csv.reader(open("/Users/Carol/Desktop/GTEx_Analysis_v6_RNA-seq_RNA-SeQCv1.1.8_gene_reads.gct", "rb")))
csv.writer(open("Gtexdata.csv", "wb")).writerows(a)

with open("/Users/carol/Desktop/Gtex-brain.txt") as f,open("Gtexdata.csv") as f2:
    # male set of lines stripping newlines
    # so we can compare properly later i.e foo\n != foo
    st  = set(map(str.rstrip, f)) # itertools.imap python2
    for line in f2:
        # split once and extract first element to compare
        if line.strip() and line.split(None, 1)[0] in st:
            print(line.rstrip()) 




